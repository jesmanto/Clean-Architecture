package com.raywenderlich.android.majesticreader.framework

class Interactors()