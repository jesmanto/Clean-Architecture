package com.raywenderlich.android.majesticreader

class MyClass {
}